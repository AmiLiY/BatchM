'''

'''
from django.shortcuts import HttpResponse,render

# 显示首页
def index(request):
    return render(request,'index.html')