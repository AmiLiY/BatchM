from django.apps import AppConfig


class BatchConfig(AppConfig):
    name = 'Batch'
