#!/usr/bin/env python
'''

'''
import os
import sys

path = os.path.dirname( os.path.dirname( __file__ ) )
sys.path.append( path )


from django.conf.urls import url,include
from django.contrib import admin
from Batch import views

urlpatterns = [
    url(r'GetServerHostStatus$',views.server_host_status,name="get_server_host_status"),#获取运行次系统的服务状态信息
    url(r"^saltstack.html$",views.saltstack_index,)
]

