from django.shortcuts import render
from django.shortcuts import HttpResponse,HttpResponseRedirect
import json
import sys,os
# Create your views here.


def server_host_status(request):
    '''
    获取运行此系统的服务器cpu和内存的使用方法，供首页展示
    :param request:
    :return:
    '''
    if sys.platform != "win32":   # if the platform is not windowns,then these code will be execute.just get cpu and mem \
        # useage from localhost
        Usages = os.popen('sh %s/plugs/get_cpu.sh' %os.path.dirname(__file__) ).read()
        Usage = {}
        Usage['cpu_usage'],Usage['mem_usage'] = Usages.split('\n')[0].split('.')[0],Usages.split('\n')[1].split('.')[0]
    else:
        Usage = {'cpu_usage': '35', 'mem_usage': '68'}
    # 获取IP的
    if "HTTP_X_FORWARDED_FOR" in request.META:
        ip = request.META['HTTP_X_FORWARDED_FOR']
    else:
        ip = request.META['REMOTE_ADDR']

    return HttpResponse(json.dumps(Usage))

def saltstack_index(request):
    '''
    展现出saltstack主机数量，group数量，以及待认证的服务器。
    :param request:
    :return:
    '''
    return render(request,'saltstack.html')

