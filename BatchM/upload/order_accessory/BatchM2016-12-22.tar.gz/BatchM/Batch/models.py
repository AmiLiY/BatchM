from django.db import models

# Create your models here.

class SaltstackMinions(models.Model):
    '''
    记录saltstack minion信息
    '''
    ip = models.GenericIPAddressField(u'IP')
    hostname = models.CharField(u'Minion的主机名',max_length=255)
    tags = models.CharField(max_length=2048)

class SaltstackGroup (models.Model):
    '''
    记录saltstack组信息
    '''
    group_name = models.CharField(u'组名',max_length=255)
    group_number = models.ManyToManyField(SaltstackMinions,verbose_name='组成员',null=True,blank=True)
    whether_create = models.IntegerField(u'是否创建了组在saltstack配置文件里',default=0) #0：没有创建，1：表示创建了
    tags = models.CharField(max_length=2048)

class SaltstackMinionsStatus(models.Model):
    '''
    记录saltstack Minions 的状态信息,存放历史状态记录的。
    '''
    # asset = models.ForeignKey('Asset',verbose_name='资产编号')
    ipaddress = models.GenericIPAddressField(u'IP')
    hostname = models.CharField(u'主机名',max_length=128)
    zombie_process =  models.IntegerField(u'僵死进程数量')
    mem_use_precent = models.FloatField(u'内存使用率',max_length=4)
    up_time = models.CharField(u'系统运行时间',max_length=128)
    load_average_fiveMin_ago = models.FloatField(u'系统五分钟以内的负载')
    cpu_ioWait = models.FloatField(u'CPU IoWait')
    login_users = models.CharField(u'登陆用户数量',max_length=128)
    disk_max_usage = models.FloatField(u'磁盘最大使用率')
    update_time = models.DateTimeField(u'数据更新时间')
    poweron_time = models.DateTimeField(u'系统开机时间',)

    def __str__(self):
        return self.hostname

    class Meta:
        verbose_name = '系统5分钟内运行状态'
        verbose_name_plural =  '系统5分钟内运行状态'


class NewSaltstackMinionsStatus(models.Model):
    '''
    记录saltstack Minions 的状态信息,存放最新的状态记录的。
    '''
    # asset = models.ForeignKey('Asset',verbose_name='资产编号')
    ipaddress = models.GenericIPAddressField(u'IP')
    hostname = models.CharField(u'主机名',max_length=128)
    zombie_process =  models.IntegerField(u'僵死进程数量')
    mem_use_precent = models.FloatField(u'内存使用率',max_length=4)
    up_time = models.CharField(u'系统运行时间',max_length=128)
    load_average_fiveMin_ago = models.FloatField(u'系统五分钟以内的负载')
    cpu_ioWait = models.FloatField(u'CPU IoWait')
    login_users = models.CharField(u'登陆用户数量',max_length=128)
    disk_max_usage = models.FloatField(u'磁盘最大使用率')
    update_time = models.DateTimeField(u'数据更新时间')
    poweron_time = models.DateTimeField(u'系统开机时间',)

    def __str__(self):
        return self.ipaddress

    class Meta:
        verbose_name = '系统状态'
        verbose_name_plural =  '系统状态'




