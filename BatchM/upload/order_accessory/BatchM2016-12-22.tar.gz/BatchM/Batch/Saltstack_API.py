'''
这个模块主要用来调用saltstack-api来完成实现的功能
'''
import saltapi